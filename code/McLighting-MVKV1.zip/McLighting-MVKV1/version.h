#define SKETCH_VERSION "2.2.5-mvk"
